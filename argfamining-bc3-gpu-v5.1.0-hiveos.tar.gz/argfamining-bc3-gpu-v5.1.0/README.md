# ArgfaMining BC3 (BitcoinIII) GPU Miner — HiveOS — v5.1.0 AURORA-MULTI

**⚠️ CLOSED SOURCE — Solo equipo ArgfaMining. No distribuir source code.**

Miner oficial de BC3 (SHA3-256t) empaquetado como **HiveOS Custom Miner**. Envuelve el
binario **Linux headless v5.1.0** (el mismo validado end-to-end) con los 4 scripts de
integración de HiveOS. **Multi-GPU** nativo (usa todas las placas NVIDIA soportadas del rig
con un solo proceso). Mina **exclusivamente** a la pool ArgfaMining.

## Novedad v5.1.0 — cuarto endpoint INDIA/Mumbai

El único cambio vs v5.0.0 es el cuarto PoP regional: **INDIA · Mumbai** (`--region in`,
`stratum-in.argfamining.com`, AWS `ap-south-1`). Todo lo demás byte-idéntico.

## Instalar en un rig HiveOS

1. Hosteá el paquete `argfamining-bc3-gpu-v5.1.0-hiveos.tar.gz` en cualquier URL alcanzable.
   En HiveOS creá un **Flight Sheet** con:
   - **Coin**: `Custom`
   - **Wallet**: tu dirección BC3 (`1…`/`3…`/`bc1…`)
   - **Miner**: `Custom`
   - **Installation URL**: la URL del `.tar.gz`
   - **Hash algorithm**: `sha3-256t`
2. En **Extra config arguments** del miner, elegí región y modo:
   ```
   --region in --mode prop
   ```
   - **region**: `latam` (Venezuela) · `usa` (Virginia) · `eu` (Frankfurt) · **`in` (Mumbai)**
   - **mode**: `solo` (99% del bloque, 1% fee) · `prop` (reparto por shares)
   - Si se omite: default `--region usa --mode prop`.
   - Otros flags opcionales: `--intensity 22..31`, `--devices 0,1` (elegir placas).
3. Aplicá el flight sheet. HiveOS instala el paquete y arranca a minar en **todas las GPUs
   soportadas** automáticamente.

## Notas

- **Requisitos**: NVIDIA **sm_75+** (Turing RTX 20xx → Ampere → Ada → Blackwell RTX 50xx).
  AMD (OpenCL) también soportado si el rig tiene el ICD. La `libcudart.so.13` viene **incluida**
  en el paquete (no depende del CUDA Toolkit del rig).
- **Pool-locked**: el build público mina solo a ArgfaMining — el Pool URL del flight sheet se
  ignora; la región elige el endpoint (los hosts están XOR-obfuscados en el binario).
- **Self-test**: al arrancar corre el self-test del kernel (Tier 1 FIPS-202 + Tier 2 CPU==GPU).
  Si imprime `FAIL`, no mina. `verify_fail` debe quedar en 0.
- **Stats**: hashrate + shares aceptadas/rechazadas se reportan al dashboard de HiveOS vía
  `h-stats.sh` (temps/fans desde `nvidia-smi`).

## Contenido del paquete

`h-manifest.conf` · `h-config.sh` · `h-run.sh` · `h-stats.sh` · `argfamining-bc3-gpu` (binario Linux x64) · `libcudart.so.13`

## Reproducir

El binario sale del build Linux (`../../linux/development/v5.1.0/`, `cmake --build` en WSL2/Linux).
El paquete HiveOS lo arma `miners/tools/gpu tools/package-hiveos.sh 5.1.0` (en WSL2/Linux).

Soporte: <https://discord.gg/nZTu2QC2YC>
