#!/usr/bin/env bash
# ArgfaMining BC3 GPU miner (AURORA-MULTI v5.1.0) - HiveOS h-run.sh - arranca el miner.
cd "$(dirname "$0")"
# Config escrita por h-config.sh en un path fijo del dir del miner (NO depende de
# CUSTOM_CONFIG_FILENAME, que HiveOS puede no exportar — ver h-config.sh).
[[ -f ./miner-config.env ]] && . ./miner-config.env

# libcudart.so.12 viene incluida en esta carpeta (el binario la linkea dinamicamente);
# la agregamos al LD_LIBRARY_PATH para no depender del CUDA Toolkit del rig.
export LD_LIBRARY_PATH="$(pwd):${LD_LIBRARY_PATH:-}"

# Mina EXCLUSIVAMENTE a la pool ArgfaMining (region-locked; endpoints XOR-obfuscados en el
# binario). MULTI-GPU nativo: usa TODAS las placas NVIDIA soportadas (sm_75+) del rig con un
# solo proceso (un thread por placa), worker unico, hashrate sumado. region/mode salen de
# USER_CONFIG ("Extra config arguments": --region latam|usa|eu|in --mode solo|prop).
# Si no se especifica, el binario usa region=usa / mode=prop por defecto.
exec ./argfamining-bc3-gpu \
  --wallet "$WAL" \
  --worker "$WORKER" \
  $USER_CONFIG 2>&1 | tee "${CUSTOM_LOG_BASENAME:-./miner}.log"
