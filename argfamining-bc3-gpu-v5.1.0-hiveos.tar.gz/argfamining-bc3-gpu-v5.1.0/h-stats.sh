#!/usr/bin/env bash
# ArgfaMining BC3 GPU miner (AURORA-MULTI v5.1.0) - HiveOS h-stats.sh
# HiveOS SOURCEA este script cada ~10 s. Debe setear dos variables:
#   khs   -> hashrate total en kh/s (para el resumen del dashboard)
#   stats -> JSON con hs[]/temp[]/fan[]/uptime/ar[]/... (detalle por-GPU)
# Si no hay datos, se dejan en cero/vacio (HiveOS muestra el miner offline/starting).

stats=""
khs=0

log="${CUSTOM_LOG_BASENAME}.log"
[[ ! -f $log ]] && return

# El miner imprime una linea de stats cada N s (formato fijo, hashrate SIEMPRE en MH/s):
#   [mining]  721.22 MH/s | shares 11/0 (acc/rej) | blocks 0 | int 29 | GPU 56C 198W 100% ... | ...
line=$(grep '\[mining\]' "$log" | tail -1)
[[ -z $line ]] && return

mhs=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+ MH/s' | grep -oE '^[0-9.]+')
sh=$(echo  "$line" | grep -oE 'shares [0-9]+/[0-9]+' | grep -oE '[0-9]+/[0-9]+')
mhs=${mhs:-0}
acc=$(echo "$sh" | cut -d/ -f1); rej=$(echo "$sh" | cut -d/ -f2)
acc=${acc:-0}; rej=${rej:-0}

# Uptime del proceso del miner (el CLI no lo imprime en la linea de stats).
pid=$(pgrep -f 'argfamining-bc3-gpu' | head -1)
up=0; [[ -n $pid ]] && up=$(ps -o etimes= -p "$pid" 2>/dev/null | tr -d ' ')
up=${up:-0}

# Telemetria por-GPU desde nvidia-smi (el CLI reporta el hashrate agregado, no per-GPU).
mapfile -t temps < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null)
mapfile -t fans  < <(nvidia-smi --query-gpu=fan.speed        --format=csv,noheader,nounits 2>/dev/null | tr -d ' %')
mapfile -t buses < <(nvidia-smi --query-gpu=pci.bus_id       --format=csv,noheader          2>/dev/null | awk -F: '{print strtonum("0x"$2)}')
n=${#temps[@]}; [[ $n -lt 1 ]] && n=1

# El binario reporta el hashrate AGREGADO; se reparte parejo entre las N placas para el
# detalle por-GPU (unidad "hs" = h/s; HiveOS auto-escala en el dashboard).
total_hs=$(awk "BEGIN{printf \"%.0f\", $mhs*1e6}")   # MH/s -> h/s
per=$(awk "BEGIN{printf \"%.0f\", $total_hs/$n}")
khs=$(awk "BEGIN{printf \"%.0f\", $mhs*1e3}")         # MH/s -> kh/s (total)

hs=$(for ((i=0;i<n;i++)); do echo "$per"; done | jq -cs '.')
temp=$(printf '%s\n' "${temps[@]}" | jq -cs 'map(tonumber? // 0)')
fan=$(printf '%s\n'  "${fans[@]}"  | jq -cs 'map(tonumber? // 0)')
bus=$(printf '%s\n'  "${buses[@]}" | jq -cs 'map(tonumber? // 0)')

stats=$(jq -nc \
  --argjson hs   "$hs"   --argjson temp "$temp" --argjson fan "$fan" --argjson bus "$bus" \
  --arg     ver  "${CUSTOM_VERSION:-5.1.0}" \
  --argjson acc  "${acc:-0}" --argjson rej "${rej:-0}" --argjson up "${up:-0}" \
  '{hs: $hs, hs_units: "hs", temp: $temp, fan: $fan, uptime: $up, ver: $ver, ar: [$acc, $rej], algo: "sha3-256t", bus_numbers: $bus}')
