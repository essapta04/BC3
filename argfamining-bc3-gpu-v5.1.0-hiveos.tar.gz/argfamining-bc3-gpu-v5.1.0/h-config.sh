#!/usr/bin/env bash
# ArgfaMining BC3 GPU miner (AURORA-MULTI v5.1.0) - HiveOS h-config.sh
# Genera la config del miner desde el flight sheet. HiveOS provee en el entorno:
#   CUSTOM_TEMPLATE   -> wallet (con %WAL% ya sustituido por HiveOS)
#   CUSTOM_USER_CONFIG-> "Extra config arguments" (aca van --region/--mode), ej: --region in --mode prop
#   WORKER_NAME       -> nombre del rig
# NO usamos CUSTOM_CONFIG_FILENAME: en el HiveOS de Filipao llegó VACÍO (2026-07-24) →
# "cat > '': No such file or directory" y el WAL nunca se pasaba. Ver abajo.
[[ -z $CUSTOM_TEMPLATE ]] && echo "h-config: CUSTOM_TEMPLATE vacio" && return 1

# El template puede venir como "wallet" o "wallet.worker"; tomamos solo la wallet.
WAL=$(echo "$CUSTOM_TEMPLATE" | cut -d. -f1)
WORKER="${WORKER_NAME:-$(hostname)}"

# Config a un path FIJO dentro del dir del propio miner. ${BASH_SOURCE[0]} da la ruta de
# ESTE script aunque HiveOS lo 'source' en vez de ejecutarlo directo (con $0 fallaría).
# h-run.sh lee del mismo lugar (./miner-config.env), así que no dependemos de HiveOS.
CONF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/miner-config.env"
cat > "$CONF" <<EOF
WAL="$WAL"
WORKER="$WORKER"
USER_CONFIG="$CUSTOM_USER_CONFIG"
EOF
